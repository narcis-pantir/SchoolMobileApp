package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.GradeAdapter;
import com.student.management.Models.GradeModel;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class GradeActivity extends AppCompatActivity {
    ImageView imageViewBack;
    TextView textVIewAssignmentName;
    RecyclerView recyclerView;
    LinearLayout layoutEmpty;
    String id="";
    String name="";
    String operationType="";
    List<GradeModel> gradeModels;
    List<GradeModel> gradeModelsList;
    List<String>   ids;

    List<UserModel> userModels;
    List<String> userIDs;

    GradeAdapter gradeAdapter;
    MyHelper myHelper;
    DatabaseReference referenceUsers,referenceGrade;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade);
        myHelper =new MyHelper(this);
        userModels=new ArrayList<>();
        userIDs=new ArrayList<>();
        gradeModels=new ArrayList<>();
        getIntentData();
        initDB();
        initViews();
        initRecyclerView();
        BuildStudentList();
    }

    private void initDB() {
        referenceUsers= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
        referenceGrade=FirebaseDatabase
                .getInstance()
                .getReference()
                .child("assignments")
                .child(id)
                .child("grades");
    }
    private void BuildStudentList() {
        Dialog dialog= myHelper.openNetLoaderDialog();
        referenceGrade.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot data:snapshot.getChildren()){
                    gradeModels.add(data.getValue(GradeModel.class));
                    ids.add(data.getKey());
                }
                referenceUsers.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        userModels.clear();
                        userIDs.clear();
                        dialog.dismiss();
                        for(DataSnapshot data:snapshot.getChildren()){
                             UserModel um=data.child("profileData").getValue(UserModel.class);
                             if(um.getAccountType().equals("student")){
                                 userModels.add(um);
                                 userIDs.add(data.getKey());
                             }
                        }
                        if(gradeModels.size()>0){
                            gradeModelsList.addAll(gradeModels);
                        }
                        for(int i=0;i<userModels.size();i++){
                            boolean founder=false;
                            for(int j=0;j<gradeModels.size();j++){
                                if(gradeModels.get(j).getStudentID().equals(userIDs.get(i))){
                                    founder=true;
                                    break;
                                }
                            }
                            if(!founder){
                                GradeModel gm=new GradeModel();
                                gm.setStudentID(userIDs.get(i));
                                gm.setStudentName(userModels.get(i).getName());
                                gm.setStudentGrade("");
                                gradeModelsList.add(gm);
                            }
                        }
                      if(gradeModelsList.size()>0){
                          layoutEmpty.setVisibility(View.GONE);
                          recyclerView.setVisibility(View.VISIBLE);
                      }else {
                          layoutEmpty.setVisibility(View.VISIBLE);
                          recyclerView.setVisibility(View.GONE);
                      }
                     gradeAdapter.notifyDataSetChanged();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                      dialog.dismiss();
                        Toast.makeText(GradeActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(GradeActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            }
        });
    }
    private void initRecyclerView() {
        gradeModelsList=new ArrayList<>();
        ids=new ArrayList<>();
        gradeAdapter=new GradeAdapter(gradeModelsList,this,operationType);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(gradeAdapter);
        gradeAdapter.setOnItemClickListener(new GradeAdapter.onItemClickListener() {
            @Override
            public void grades(int position) {
               openDialogGrade(position);

            }
        });
    }

    private void openDialogGrade(int position) {
        Dialog dialog=new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_add_grade);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        TextView textViewStudentName
                ,textViewAssignmentName,textViewCancel
                ,textViewSubmit;
        EditText editTextTitle;


        textViewStudentName=dialog.findViewById(R.id.textViewStudentName);
        textViewAssignmentName=dialog.findViewById(R.id.textViewAssignmentName);
        textViewCancel=dialog.findViewById(R.id.textViewCancel);
        textViewSubmit=dialog.findViewById(R.id.textViewSubmit);
        editTextTitle=dialog.findViewById(R.id.editTextTitle);
        textViewStudentName.setText(gradeModelsList.get(position).getStudentName());
        textViewAssignmentName.setText(name);
        textViewCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        textViewSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               String grade=editTextTitle.getText().toString();
               if(grade.equals("")){
                   Toast.makeText(GradeActivity.this, "Please enter grade ", Toast.LENGTH_SHORT).show();
               }else {
                   gradeModelsList.get(position).setStudentGrade(grade);
                   GradeModel neGrdModel=gradeModelsList.get(position);
                   uploadNewGrade(neGrdModel);
                   dialog.dismiss();
                   gradeAdapter.notifyDataSetChanged();
               }
            }
        });
    }

    private void uploadNewGrade(GradeModel neGrdModel) {
        Dialog dialog= myHelper.openNetLoaderDialog();
        referenceGrade.child(neGrdModel.getStudentID())
                .setValue(neGrdModel).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(GradeActivity.this, "Grade of "+neGrdModel.getStudentName()+" successfully uploaded ", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                     dialog.dismiss();
                        Toast.makeText(GradeActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void getIntentData() {
        id=getIntent().getStringExtra("assignmentID");
        name=getIntent().getStringExtra("assignmentName");
        operationType=getIntent().getStringExtra("operationType");
    }
    private void initViews() {
        imageViewBack=findViewById(R.id.imageViewBack);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        textVIewAssignmentName=findViewById(R.id.textVIewAssignmentName);
        textVIewAssignmentName.setText(name);
        recyclerView=findViewById(R.id.recyclerView);
        layoutEmpty=findViewById(R.id.layoutEmpty);
    }
}