package com.student.management.Students.Fragments;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.student.management.Account.LoginActivity;
import com.student.management.Data.LocalData;
import com.student.management.Models.UserModel;
import com.student.management.Parents.AllTeacherActivity;
import com.student.management.R;
import com.student.management.Teachers.AllParentsActivity;

public class ProfileFragment extends Fragment {
    View view;
    ImageView imageViewProfileImage,imageViewLogout;
    TextView textViewNameTop,textViewName
            ,textViewEmail,textViewPhoneNumber;
    TextView textViewStudentID;
    Button buttonShareID;
    DatabaseReference reference;
    FirebaseAuth auth;
    FirebaseUser user;
    LocalData localData;
    LinearLayout layoutParents,layoutStudent;

    ImageView imageVIewChildProfile;
    TextView textViewChildName;
    Button buttonProfile,buttonContactOtherParents;




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_profile, container, false);
        localData=new LocalData(getContext());
        initDB();
        initViews();
        getUserData();
        return view;
     }

    private void getUserData() {
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    UserModel userModel=snapshot.getValue(UserModel.class);
                    textViewName.setText(userModel.getName());
                    textViewEmail.setText(userModel.getEmail());
                    textViewPhoneNumber.setText(userModel.getPhoneNumber());
                    textViewNameTop.setText(userModel.getName());
                    if(!userModel.getImageURL().equals("")){
                        downalodImage(userModel.getImageURL());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }

    private void downalodImage(String imageURL) {
        Picasso.get().load(imageURL).placeholder(getResources()
                .getDrawable(R.drawable.person_place_holder))
                .into(imageViewProfileImage);
    }

    private void initDB() {
    auth=FirebaseAuth.getInstance();
    user=auth.getCurrentUser();
    reference=FirebaseDatabase
            .getInstance()
            .getReference()
            .child("users")
            .child(user.getUid())
            .child("profileData");
    }
    private void initViews() {
        textViewStudentID=view.findViewById(R.id.textViewStudentID);
        buttonShareID=view.findViewById(R.id.buttonShareID);
        buttonProfile=view.findViewById(R.id.buttonProfile);
        layoutParents=view.findViewById(R.id.layoutParents);
        layoutStudent=view.findViewById(R.id.layoutStudent);
        imageVIewChildProfile=view.findViewById(R.id.imageVIewChildProfile);
        textViewChildName=view.findViewById(R.id.textViewChildName);
        imageViewProfileImage=view.findViewById(R.id.imageViewProfileImage);
        imageViewLogout=view.findViewById(R.id.imageViewLogout);
        textViewNameTop=view.findViewById(R.id.textViewNameTop);
        textViewName=view.findViewById(R.id.textViewName);
        textViewEmail=view.findViewById(R.id.textViewEmail);
        textViewPhoneNumber=view.findViewById(R.id.textViewPhoneNumber);
        buttonContactOtherParents=view.findViewById(R.id.buttonContactOtherParents);
        buttonContactOtherParents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AllParentsActivity.class));
            }
        });


        imageViewLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 openLogout();
            }
        });
        textViewStudentID.setText(user.getUid());
        buttonShareID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(android.content.Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
                intent.putExtra(android.content.Intent.EXTRA_TEXT, user.getUid());
                startActivity(Intent.createChooser(intent, "Select application"));
            }
        });
        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getActivity(), AllTeacherActivity.class));
            }
        });


   if(localData.getLogin().getAccountType().equals("student")){
       layoutParents.setVisibility(View.GONE);
   }else {
       layoutStudent.setVisibility(View.GONE);
       downloadStudentData();
   }

    }

    private void downloadStudentData() {
       DatabaseReference  referenceStudent=FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users")
                .child(localData.getLogin().getStudentID())
                .child("profileData");
       referenceStudent.addListenerForSingleValueEvent(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot snapshot) {
               if(snapshot.exists()){
                   UserModel userModel=snapshot.getValue(UserModel.class);
                   textViewChildName.setText(userModel.getName());
                   if(!userModel.getImageURL().equals("")){
                       Picasso.get().load(userModel.getImageURL())
                               .placeholder(getResources().getDrawable(R.drawable.person_place_holder))
                               .into(imageVIewChildProfile);
                   }

               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError error) {

           }
       });



    }

    private void openLogout() {
        new AlertDialog.Builder(getContext())
                .setMessage("Are you sure to logout from this application?")
                .setNegativeButton("NO", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if(user!=null){
                            auth.signOut();
                            getActivity().finish();
                            startActivity(new Intent(getActivity(), LoginActivity.class));
                        }

                    }
                })
                .show();
    }

}