package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.student.management.Models.Message;
import com.student.management.R;
import java.util.List;


public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.CustomViewHolder> {
    List<Message> messages;
    Context context;
    String operationType;
    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  confirm(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          TextView txtName,txtMessage,txtMessageDate;
          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              txtName=itemView.findViewById(R.id.txtName);
              txtMessage=itemView.findViewById(R.id.txtMessage);
              txtMessageDate=itemView.findViewById(R.id.txtMessageDate);
        }
    }
    public ChatAdapter(List<Message> messages, Context context, String type) {
        this.messages =messages;
        this.context = context;
        this.operationType=type;
    }
    @Override
    public int getItemViewType(int position) {
          if(messages.get(position).getMessageType().equals("my")){
              return R.layout.user_message;
          }
          return R.layout.incoming_message;
    }
    @Override
    public int getItemCount() {
        return  messages.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
          holder.txtName.setText(messages.get(position).getUserName());
          holder.txtMessage.setText(messages.get(position).getMessage());
          holder.txtMessageDate.setText(messages.get(position).getDate());
      }
}
