package com.student.management.Students.Fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.InboxAdapter;
import com.student.management.ChatActivity;
import com.student.management.Models.Inbox;
import com.student.management.Models.UserModel;
import com.student.management.R;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InboxFragment extends Fragment {
     View view;
    LinearLayout layoutEmpty,layoutLoading;
    RecyclerView recyclerView;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference,referenceUser;
    List<Inbox> inboxes;
    InboxAdapter inboxAdapter;
    UserModel userModel=null;
    public InboxFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view= inflater.inflate(R.layout.fragment_inbox, container, false);
        initDB();
        initUi();
        initRecyclerView();
        getUserData();
        return view;
    }
    private void getUserData() {
        if(userModel==null){
            referenceUser.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                    userModel=snapshot.getValue(UserModel.class);
                    getAllContactList();

                }

                @Override
                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                }
            });

        }else {
            getAllContactList();
        }
    }

    private void getAllContactList() {
        recyclerView.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                inboxes.clear();
                layoutLoading.setVisibility(View.GONE);

                for(DataSnapshot data:snapshot.getChildren()){
                    Inbox inbox=new Inbox();
                    inbox.setId(data.getKey());
                    inboxes.add(inbox);
                }
                Collections.reverse(inboxes);

                if(inboxes.size()>0){
                    recyclerView.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }else {
                    recyclerView.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                }

                inboxAdapter.notifyDataSetChanged();

            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
    private void initRecyclerView() {
        inboxes=new ArrayList<>();
        inboxAdapter = new InboxAdapter(inboxes, getContext(),"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(inboxAdapter);
        inboxAdapter.setOnItemClickListener(new InboxAdapter.onItemClickListener() {
            @Override
            public void contact(int position) {
                Intent intent=new Intent(getActivity(), ChatActivity.class);
                intent.putExtra("chatID",inboxes.get(position).getId());
                intent.putExtra("name",userModel.getName());
                startActivity(intent);
            }
        });
    }
    private void initUi() {
        layoutEmpty=view.findViewById(R.id.layoutEmpty);
        layoutLoading=view.findViewById(R.id.layoutLoading);
        recyclerView=view.findViewById(R.id.recyclerView);

    }
    private void initDB() {
        auth= FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference()
                .child("chatBox")
                .child(user.getUid());
        referenceUser= FirebaseDatabase.getInstance().getReference()
                .child("users")
                .child(user.getUid())
                .child("profileData");
    }



}