package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.InboxAdapter;
import com.student.management.ChatActivity;
import com.student.management.Models.Inbox;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class InboxActivity extends AppCompatActivity {
    LinearLayout layoutEmpty;
    RecyclerView recyclerView;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference,referenceUser;
    List<Inbox> inboxes;
    InboxAdapter inboxAdapter;
    MyHelper myHelper;
    UserModel userModel=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myHelper =new MyHelper(this);
        setContentView(R.layout.activity_inbox);
        initDB();
        initUi();
        initRecyclerView();
        getUserData();
    }
    private void getUserData() {
        if(userModel==null){

            Dialog dialog= myHelper.openNetLoaderDialog();
            referenceUser.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                    dialog.dismiss();
                    userModel=snapshot.getValue(UserModel.class);
                    getAllContactList();

                }

                @Override
                public void onCancelled(@NonNull @NotNull DatabaseError error) {

                }
            });

        }else {
            getAllContactList();
        }
    }

    private void getAllContactList() {
        recyclerView.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        Dialog dialog = myHelper.openNetLoaderDialog();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                inboxes.clear();
                dialog.dismiss();

                for(DataSnapshot data:snapshot.getChildren()){
                    Inbox inbox=new Inbox();
                    inbox.setId(data.getKey());
                    inboxes.add(inbox);
                }
                Collections.reverse(inboxes);

                if(inboxes.size()>0){
                    recyclerView.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }else {
                    recyclerView.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                }

                inboxAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

    private void initRecyclerView() {
        inboxes=new ArrayList<>();
        inboxAdapter = new InboxAdapter(inboxes, this,"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(inboxAdapter);
        inboxAdapter.setOnItemClickListener(new InboxAdapter.onItemClickListener() {
            @Override
            public void contact(int position) {
                Intent intent=new Intent(InboxActivity.this, ChatActivity.class);
                intent.putExtra("chatID",inboxes.get(position).getId());
                intent.putExtra("name",userModel.getAccountType());
                startActivity(intent);
            }
        });


    }

    private void initUi() {
        layoutEmpty=findViewById(R.id.layoutEmpty);
        recyclerView=findViewById(R.id.recyclerView);
       findViewById(R.id.imageViewBack).setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               finish();
           }
       });
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference()
                .child("chatBox")
                .child(user.getUid());
        referenceUser= FirebaseDatabase.getInstance().getReference()
                .child("users")
                .child(user.getUid())
                .child("profileData");
    }

}