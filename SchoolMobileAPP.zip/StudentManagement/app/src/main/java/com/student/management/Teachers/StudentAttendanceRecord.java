package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.AttendanceAdapter;
import com.student.management.Models.Attendance;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class StudentAttendanceRecord extends AppCompatActivity {
     RecyclerView recyclerView;
     LinearLayout layoutEmpty;
     ImageView imageViewBack;
     TextView textVIewName,textVIewEmail,textVIewPhoneNumber;
     String name;
     String email;
     String phone;
     String id;
     MyHelper myHelper;
     List<Attendance> attendances;
     AttendanceAdapter attendanceAdapter;
     DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_attendance_record);
        myHelper =new MyHelper(this);
        getIntentData();
        initDB();
        initViews();
        initRecyclerView();
        getAllAttendance();
    }
    private void getAllAttendance() {
        Dialog dialog= myHelper.openNetLoaderDialog();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                for(DataSnapshot data:snapshot.getChildren()){
                    attendances.add(data.getValue(Attendance.class));
                }
                if(attendances.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                attendanceAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void initDB() {
      reference= FirebaseDatabase
              .getInstance()
              .getReference()
              .child("users")
              .child(id)
              .child("attendance");

    }
    private void initRecyclerView() {
        attendances=new ArrayList<>();
        attendanceAdapter=new AttendanceAdapter(attendances,this,"student");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(attendanceAdapter);


    }

    private void getIntentData() {
        name=getIntent().getStringExtra("name");
        email=getIntent().getStringExtra("email");
        phone=getIntent().getStringExtra("phone");
        id=getIntent().getStringExtra("id");
    }

    private void initViews() {
        recyclerView=findViewById(R.id.recyclerView);
        layoutEmpty=findViewById(R.id.layoutEmpty);
        imageViewBack=findViewById(R.id.imageViewBack);
        textVIewName=findViewById(R.id.textVIewName);
        textVIewEmail=findViewById(R.id.textVIewEmail);
        textVIewPhoneNumber=findViewById(R.id.textVIewPhoneNumber);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        textVIewEmail.setText(email);
        textVIewName.setText(name);
        textVIewPhoneNumber.setText(phone);


    }
}