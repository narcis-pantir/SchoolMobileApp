package com.student.management.Students.Fragments;
import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.PostAdapter;
import com.student.management.Data.LocalData;
import com.student.management.Models.PostModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class PostFragment extends Fragment {
    View view;
    LinearLayout layoutEmpty,layoutLoading;
    RecyclerView recyclerView;
    DatabaseReference referencePost;
    List<PostModel> postModels;
    List<String> ids;
    PostAdapter postAdapter;
    FloatingActionButton floatingActionButton2;
    LocalData localData;
    FirebaseAuth auth;
    FirebaseUser user;
    MyHelper myHelper;

    public PostFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view= inflater.inflate(R.layout.fragment_posts, container, false);
        localData=new LocalData(getContext());
        myHelper =new MyHelper(getContext());
        initDB();
        initViews();
        initRecyclerView();
        getAllPosts();
        return  view;
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        referencePost= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("posts");
    }
    private void getAllPosts() {
        recyclerView.setVisibility(View.GONE);
        layoutEmpty.setVisibility(View.GONE);
        layoutLoading.setVisibility(View.VISIBLE);
        referencePost.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ids.clear();
                postModels.clear();
                layoutLoading.setVisibility(View.GONE);
                for(DataSnapshot data:snapshot.getChildren()){
                    postModels.add(data.getValue(PostModel.class));
                    ids.add(data.getKey());
                }
                if(postModels.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                postAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                layoutLoading.setVisibility(View.VISIBLE);
            }
        });
    }
    private void initRecyclerView() {
        postModels=new ArrayList<>();
        ids=new ArrayList<>();
        postAdapter=new PostAdapter(postModels,getContext(),"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(postAdapter);
    }
    private void initViews() {
        layoutLoading=view.findViewById(R.id.layoutLoading);
        layoutEmpty=view.findViewById(R.id.layoutEmpty);
        recyclerView=view.findViewById(R.id.recyclerView);
        floatingActionButton2=view.findViewById(R.id.floatingActionButton2);
        if(localData.getLogin().getAccountType().equals("student")){
            floatingActionButton2.setVisibility(View.GONE);
        }
        floatingActionButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogPost();
            }
        });

    }
    private void openDialogPost() {
        Dialog dialog=new Dialog(getContext(), android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_add_post);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        EditText editTextTitle,editTextDescriptions;
        TextView textViewCancel,textViewSubmit;
        editTextTitle=dialog.findViewById(R.id.editTextTitle);
        editTextDescriptions=dialog.findViewById(R.id.editTextDescriptions);
        textViewCancel=dialog.findViewById(R.id.textViewCancel);
        textViewSubmit=dialog.findViewById(R.id.textViewSubmit);
        textViewCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        textViewSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PostModel postModel=new PostModel();
                postModel.setName(localData.getLogin().getName());
                postModel.setHostID(user.getUid());
                postModel.setDateAndTime(myHelper.currentDate()+" "+ myHelper.currentTime());
                postModel.setPostDescription(editTextDescriptions.getText().toString());
                postModel.setPostTitle(editTextTitle.getText().toString());
                if(postModel.getPostTitle().equals("")){
                    editTextTitle.setError("Title required");
                }else if(postModel.getPostDescription().equals("")){
                    editTextDescriptions.setError("Post description required ");
                }else {
                    uploadPost(postModel);
                    dialog.dismiss();
                }
            }
        });
    }
    private void uploadPost(PostModel postModel) {
        Dialog dialog= myHelper.openNetLoaderDialog();
        referencePost.push().setValue(postModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                dialog.dismiss();
                Toast.makeText(getActivity(), "Posted successfully ", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }



}