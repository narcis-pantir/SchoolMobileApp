package com.student.management.Models;


// this is object class for Assignment
public class Assignment {
    String assignmentName;


    // setter and getter of the class
    public String getAssignmentName() {
        return assignmentName;
    }

    public void setAssignmentName(String assignmentName) {
        this.assignmentName = assignmentName;
    }
}
