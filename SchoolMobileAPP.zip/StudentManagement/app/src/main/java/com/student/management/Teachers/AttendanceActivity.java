package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.TakeAttendanceAdapter;
import com.student.management.Models.Attendance;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class AttendanceActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayout layoutEmpty;
    List<UserModel> userModels;
    List<String> userIds;
    TakeAttendanceAdapter takeAttendanceAdapter;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    MyHelper myHelper;
    ImageView imageViewBack;
    TextView textViewDate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myHelper =new MyHelper(this);
        setContentView(R.layout.activity_attendance);
        initDB();
        initViews();
        initRecyclerView();
        getAllUsers();
    }

    private void getAllUsers() {
        Dialog dialogLoading= myHelper.openNetLoaderDialog();
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userIds.clear();
                userModels.clear();
                dialogLoading.dismiss();
                for(DataSnapshot data:snapshot.getChildren()){
                    UserModel userModel=data.child("profileData").getValue(UserModel.class);
                    if(userModel.getAccountType().equals("student")){
                        userModels.add(userModel);
                        userIds.add(data.getKey());
                    }
                }
                if(userModels.size()>0){
                    recyclerView.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }else {
                    recyclerView.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                }
                takeAttendanceAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialogLoading.dismiss();
                Toast.makeText(AttendanceActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initRecyclerView() {
        userModels=new ArrayList<>();
        userIds=new ArrayList<>();
        takeAttendanceAdapter=new TakeAttendanceAdapter(userModels,this,"student");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(takeAttendanceAdapter);
        takeAttendanceAdapter.setOnItemClickListener(new TakeAttendanceAdapter.onItemClickListener() {
            @Override
            public void checkAttendance(int position) {
            Intent intent=new Intent(AttendanceActivity.this,StudentAttendanceRecord.class);
            intent.putExtra("name",userModels.get(position).getName());
            intent.putExtra("email",userModels.get(position).getEmail());
            intent.putExtra("phone",userModels.get(position).getPhoneNumber());
            intent.putExtra("id",userIds.get(position));
            startActivity(intent);
            }
            @Override
            public void present(int position) {
                Dialog dialog= myHelper.openNetLoaderDialog();
                Attendance attendance=new Attendance();
                attendance.setDate(myHelper.currentDate());
                attendance.setStatus("present");
                attendance.setTime(myHelper.currentTime());
                reference.child(userIds.get(position))
                        .child("attendance").child(myHelper.currentDate())
                        .setValue(attendance).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                dialog.dismiss();
                                Toast.makeText(AttendanceActivity.this,
                                        "Student "+ userModels.get(position).getName()+" Marked present",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                dialog.dismiss();
                                Toast.makeText(AttendanceActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
            @Override
            public void absent(int position) {
                Dialog dialog= myHelper.openNetLoaderDialog();
                Attendance attendance=new Attendance();
                attendance.setDate(myHelper.currentDate());
                attendance.setStatus("absent");
                attendance.setTime(myHelper.currentTime());
                reference.child(userIds.get(position))
                        .child("attendance").child(myHelper.currentDate())
                        .setValue(attendance).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                dialog.dismiss();
                                Toast.makeText(AttendanceActivity.this,
                                        "Student "+ userModels.get(position).getName()+" Marked absent",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                dialog.dismiss();
                                Toast.makeText(AttendanceActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
    }
    private void initViews() {
        recyclerView=findViewById(R.id.recyclerView);
        layoutEmpty=findViewById(R.id.layoutEmpty);
        imageViewBack=findViewById(R.id.imageViewBack);
        textViewDate=findViewById(R.id.textViewDate);
        textViewDate.setText(myHelper.currentDate());
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}