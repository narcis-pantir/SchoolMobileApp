package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.student.management.Models.Attendance;
import com.student.management.Models.UserModel;
import com.student.management.R;

import java.util.List;


public class AttendanceAdapter extends RecyclerView.Adapter<AttendanceAdapter.CustomViewHolder> {
    List<Attendance> attendances;
    Context context;
    String operationType;
    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  contact(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
     TextView textVIewAttendanceDate
             ,textViewTime,textViewStatus;
          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              textVIewAttendanceDate=itemView.findViewById(R.id.textVIewAttendanceDate);
              textViewTime=itemView.findViewById(R.id.textViewTime);
              textViewStatus=itemView.findViewById(R.id.textViewStatus);
          }
    }
    public AttendanceAdapter(List<Attendance> attendances, Context context, String type) {
        this.attendances =attendances;
        this.context = context;
        this.operationType=type;
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.attendance_item;
    }
    @Override
    public int getItemCount() {
        return  attendances.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.textVIewAttendanceDate.setText(attendances.get(position).getDate());
        holder.textViewTime.setText(attendances.get(position).getTime());
        holder.textViewStatus.setText(attendances.get(position).getStatus());
        if(attendances.get(position).getStatus().equals("present")){
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.green_color));
        }else {
            holder.textViewStatus.setTextColor(context.getResources().getColor(R.color.red_color));
        }
      }
}
