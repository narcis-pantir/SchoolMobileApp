package com.student.management.Account;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.student.management.Data.LocalData;
import com.student.management.Models.UserModel;
import com.student.management.ParentsMain;
import com.student.management.R;
import com.student.management.StudentMain;
import com.student.management.TeacherMain;
import com.student.management.Utilities.MyHelper;
import com.student.management.Utilities.StoragePermission;

import java.io.IOException;
import java.util.UUID;
@SuppressWarnings("deprecation")
public class RegistrationActivity extends AppCompatActivity {
    ImageView imageViewProfileImage;
    EditText editTextFullName,editTextEmail
            ,editTextPassword,editTextConfirmPassword;
    Button buttonSignUp;
    TextView textViewLogin;
    LinearLayout layoutID;
    Uri imageUri=null;

    MyHelper myHelper;
    Dialog dialogLoader;
    EditText editTextPhoneNumber,editTextStudentID;
    CheckBox checkBoxStudent,checkBoxTeacher
            ,checkBoxParents;
    String accountType="student";
    LocalData localData;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        myHelper =new MyHelper(this);
        localData=new LocalData(this);
        initDB();
        initViews();
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
    }
    private void initViews() {
        imageViewProfileImage=findViewById(R.id.imageViewProfileImage);
        imageViewProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean result= StoragePermission.isAllowedToReadStorage(RegistrationActivity.this);
                if(result){
                    openStorageIntent();
                }
            }
        });
        editTextStudentID=findViewById(R.id.editTextStudentID);
        layoutID=findViewById(R.id.layoutID);
        editTextFullName=findViewById(R.id.editTextFullName);
        editTextEmail=findViewById(R.id.editTextEmail);
        editTextPassword=findViewById(R.id.editTextPassword);
        editTextConfirmPassword=findViewById(R.id.editTextConfirmPassword);
        editTextPhoneNumber=findViewById(R.id.editTextPhoneNumber);
        buttonSignUp=findViewById(R.id.buttonSignUp);
        textViewLogin=findViewById(R.id.textViewLogin);
        checkBoxStudent=findViewById(R.id.checkBoxStudent);
        checkBoxTeacher=findViewById(R.id.checkBoxTeacher);
        checkBoxParents=findViewById(R.id.checkBoxParents);
        checkBoxClickListeners();

        // button Sign up click listener
        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel us=new UserModel(); // create user model

                // copy data into user model
                us.setEmail(editTextEmail.getText().toString());
                us.setName(editTextFullName.getText().toString());
                us.setImageURL("");
                us.setPhoneNumber(editTextPhoneNumber.getText().toString());
                us.setAccountType(accountType);
                us.setStudentID("");
                us.setNotificationID("");


                // validate all the data
                if(us.getEmail().equals("")){
                    editTextEmail.setError("Email Required");
                }else if(!myHelper.isEmailValid(us.getEmail())){
                    editTextEmail.setError("Invalid email");
                }else if(editTextPassword.getText().toString().equals("")){
                    editTextPassword.setError("Password required");
                }else if(!editTextPassword.getText().toString().equals(editTextConfirmPassword.getText().toString())){
                    editTextConfirmPassword.setError("Password missed matched");
                }else if(editTextPhoneNumber.getText().toString().equals("")){
                     editTextPhoneNumber.setError("Phone number required");
                }else {
                        // get student id in case of parents registration
                    String studentID=editTextStudentID.getText().toString().trim();
                    dialogLoader= myHelper.openNetLoaderDialog();

                    // check account type
                    if(accountType.equals("parents")){  // if check box parents selected
                        if(studentID.equals("")){  // check student id
                            editTextStudentID.setError("StudentID required");
                            dialogLoader.dismiss();
                        }else {
                               // other wise get student profile
                             reference.child(studentID).child("profileData").addListenerForSingleValueEvent(new ValueEventListener() {
                                 @Override
                                 public void onDataChange(@NonNull DataSnapshot snapshot) {
                                     if(!snapshot.exists()){  // if student not  exist mean invalid ID
                                         dialogLoader.dismiss();    // close dialog

                                           // display error message
                                         editTextStudentID.setError("No user found with this id : "+studentID);

                                         // also display Toast
                                         Toast.makeText(RegistrationActivity.this, "No user found with this id : "+studentID, Toast.LENGTH_SHORT).show();
                                     }else {

                                         // if student exist

                                         // get student Data
                                         UserModel userModel=snapshot.getValue(UserModel.class);

                                         // check the account type is student or not
                                         if(!userModel.getAccountType().equals("student")){
                                             dialogLoader.dismiss();

                                             // display message
                                             editTextStudentID.setError("This id not belong to any student : "+studentID);
                                             Toast.makeText(RegistrationActivity.this, "This id not belong to any student : "+studentID, Toast.LENGTH_SHORT).show();
                                         }else {   // if student ID valid
                                             us.setStudentID(studentID);  //set student ID
                                             doRegistration(us,"");  // call do registration method
                                         }
                                     }
                                 }
                                 @Override
                                 public void onCancelled(@NonNull DatabaseError error) {
                                  dialogLoader.dismiss();
                                  Toast.makeText(RegistrationActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                                 }
                             });
                        }
                    }else {   // if student or teacher checkBox  selected
                        doRegistration(us,""); // do registration without Student ID
                    }


                }
            }
        });
    }


    // check box clickListeners
    private void checkBoxClickListeners() {

        //  if student check box selected
        checkBoxStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //hide student id layout
                layoutID.setVisibility(View.GONE);
                accountType="student";  //set account type student
                restCheckBoxes();  // remove check from all check box
                checkBoxStudent.setChecked(true);  // only check student checkBox

            }
        });

        // same to above   only visible StudentID layout
        checkBoxParents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // visible student ID layout
                layoutID.setVisibility(View.VISIBLE);
                accountType="parents";
                restCheckBoxes();
                checkBoxParents.setChecked(true);

            }
        });

        //  same to above
        checkBoxTeacher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                layoutID.setVisibility(View.GONE);
                accountType="teacher";
                restCheckBoxes();
                checkBoxTeacher.setChecked(true);
            }
        });
    }

    // reset all check box
    private void restCheckBoxes() {
        checkBoxStudent.setChecked(false);
        checkBoxTeacher.setChecked(false);
        checkBoxParents.setChecked(false);
    }


    private void doRegistration(UserModel us,String studentDI) {

       // create user on firebase authentication
        // using email and password
        auth.createUserWithEmailAndPassword(us.getEmail(),editTextPassword.getText().toString()).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                user=auth.getCurrentUser();  // get current users
                uploadImage(us);  // upload image of user
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
               dialogLoader.dismiss();
               myHelper.messageDialog("Error",e.getMessage());
            }
        });


    }

    private void uploadImage(UserModel us) {

        // if user selected any image
        if(imageUri!=null){

            // upload image to firebase storage
            String  imageID="profileImages/" + UUID.randomUUID().toString();
            StorageReference reference1= FirebaseStorage.getInstance().getReference().child(imageID);
            reference1.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    Toast.makeText(RegistrationActivity.this, "Image uploaded successfully", Toast.LENGTH_SHORT).show();
                    Task<Uri> uri2=taskSnapshot.getStorage().getDownloadUrl();
                    while (!uri2.isComplete());
                    Uri uri3=uri2.getResult();
                    us.setImageURL(uri3.toString());  // set image url
                    uploadUserData(us);    // upload final data to firebase
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(RegistrationActivity.this, "can't upload image", Toast.LENGTH_SHORT).show();

                    us.setImageURL("");
                    uploadUserData(us);
                }
            });
        }else {
            us.setImageURL("");
            uploadUserData(us);
        }
    }
    private void uploadUserData(UserModel us) {
        user=auth.getCurrentUser();

        // upload user data
        reference.child(user.getUid()).child("profileData")
                .setValue(us).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Toast.makeText(RegistrationActivity.this, "Data uploaded successfully", Toast.LENGTH_SHORT).show();
                        dialogLoader.dismiss();
                            startNewTaskActivity(us);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        dialogLoader.dismiss();
                        Toast.makeText(RegistrationActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void startNewTaskActivity(UserModel userModel) {
        localData.setLogin(userModel);  // set data of user in local data
        Intent intent=null;

        // open activity according to user account type
        if(accountType.equals("teacher")){
            intent=new Intent(RegistrationActivity.this, TeacherMain.class);
        }else if(accountType.equals("student")){
            intent=new Intent(RegistrationActivity.this, StudentMain.class);
        }else if(accountType.equals("parents")){
            intent=new Intent(RegistrationActivity.this, ParentsMain.class);
        }
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
    /********  image permission functions   *****/
    private void openStorageIntent() {

        // open select image INTENT
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction( Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select File"),1);
    }
    @Override   // permission request
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
       if(requestCode==123){    // check request code
           if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
               openStorageIntent();  //  if permission granted open storage intent
           }else {
               Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
           }
       }
    }
    @Override  // after user select image
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {  // check request code
            if (requestCode == 1) {
                imageUri = data.getData();  // get image URI
                try {

                    //  get image into bitmap
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);

                   //  set bitMap on UI
                    imageViewProfileImage.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Can't get image ", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}