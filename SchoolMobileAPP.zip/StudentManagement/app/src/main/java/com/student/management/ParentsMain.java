package com.student.management;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.messaging.FirebaseMessaging;
import com.student.management.Students.Fragments.AttendanceFragment;
import com.student.management.Students.Fragments.GradeFragment;
import com.student.management.Students.Fragments.InboxFragment;
import com.student.management.Students.Fragments.PostFragment;
import com.student.management.Students.Fragments.ProfileFragment;

@SuppressWarnings("deprecation")
public class ParentsMain extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener{
    BottomNavigationView navView;  // bottom Navigation View
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parents_main);
        initDB();

        // init bottomNavigation
        initBottomNavigation();
        updateNotificationID();
    }
    private void initBottomNavigation() {
        navView = findViewById(R.id.bottom_nav);
        navView.setOnNavigationItemSelectedListener(this);
        LoadFragment(new PostFragment());  // load PostFragment First
    }
    @Override  // bottom navigation click Listener
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

       // get ID and open corresponding fragment
        if(item.getItemId()==R.id.nav_posts) {
            LoadFragment(new PostFragment());
        }else if(item.getItemId()==R.id.nav_attendance){
            LoadFragment(new AttendanceFragment());
        }else if(item.getItemId()==R.id.nav_grades) {
            LoadFragment(new GradeFragment());
        }else if(item.getItemId()==R.id.nav_profile){
            LoadFragment(new ProfileFragment());
        }else if(item.getItemId()==R.id.nav_inbox){
            LoadFragment(new InboxFragment());
        }
        return true;
    }

    // this function will load fragment
    private void LoadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(   // set animation on fragment change
                        R.anim.slide_in,  // enter
                        R.anim.fade_out,  // exit
                        R.anim.fade_in,   // popEnter
                        R.anim.slide_out  // popExit
                )
                .replace(R.id.frameLayout, fragment)
                .commit();
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users")
                .child(user.getUid());
    }

    private void updateNotificationID() {
        // do is a background
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
            @Override
            public void onSuccess(String s) {
                reference.child("profileData").child("notificationID")
                        .setValue(s);
            }
        });

    }


}