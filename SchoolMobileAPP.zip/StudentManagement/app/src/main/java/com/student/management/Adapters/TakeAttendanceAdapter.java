package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.student.management.Models.UserModel;
import com.student.management.R;

import java.util.List;


public class TakeAttendanceAdapter extends RecyclerView.Adapter<TakeAttendanceAdapter.CustomViewHolder> {
    List<UserModel> userModels;
    Context context;
    String operationType;
    DatabaseReference reference;

    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  checkAttendance(int position);
          void  present(int position);
          void  absent(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          ImageView imageViewProfileImage;
          TextView textViewName;
          CheckBox checkBoxPresent,checkBoxAbsent;
          Button buttonCheckAttendance;
          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              imageViewProfileImage=itemView.findViewById(R.id.imageViewProfileImage);
              textViewName=itemView.findViewById(R.id.textViewName);
              imageViewProfileImage=itemView.findViewById(R.id.imageViewProfileImage);
              textViewName=itemView.findViewById(R.id.textViewName);
              checkBoxPresent=itemView.findViewById(R.id.checkBoxPresent);
              checkBoxAbsent=itemView.findViewById(R.id.checkBoxAbsent);
              buttonCheckAttendance=itemView.findViewById(R.id.buttonCheckAttendance);
       checkBoxPresent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos=getAdapterPosition();
                checkBoxPresent.setChecked(true);
                checkBoxAbsent.setChecked(false);
                if(listener!=null){
                    listener.present(pos);
                }
            }
        });
              checkBoxAbsent.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      checkBoxAbsent.setChecked(true);
                      checkBoxPresent.setChecked(false);
                      int pos=getAdapterPosition();
                      if(listener!=null){
                          listener.absent(pos);
                      }
                  }
              });
              buttonCheckAttendance.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View view) {
                      int pos=getAdapterPosition();
                      if(listener!=null){
                          listener.checkAttendance(pos);
                      }
                  }
              });

          }
    }
    public TakeAttendanceAdapter(List<UserModel> userModels, Context context, String type) {
        this.userModels =userModels;
        this.context = context;
        this.operationType=type;
        reference= FirebaseDatabase.getInstance().getReference()
                .child("users");
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.take_attendance_item;
    }
    @Override
    public int getItemCount() {
        return  userModels.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
    holder.textViewName.setText(userModels.get(position).getName());
     if(!userModels.get(position).getImageURL().equals("")) {
         Picasso.get().load(userModels.get(position).getImageURL())
                 .placeholder(context.getDrawable(R.drawable.person_place_holder))
                 .into(holder.imageViewProfileImage);
     }
      }
}
