package com.student.management.Data;

import static android.content.Context.MODE_PRIVATE;
import android.content.Context;
import android.content.SharedPreferences;
import com.student.management.Models.UserModel;

public class LocalData {
    Context context;  // activity context

    //  constructor initialize context
    public LocalData(Context context) {
        this.context=context;
    }

    // set login function get UserModel and stored it in sharedPrefrences
    public void setLogin(UserModel userModel){

        // create sharedPreferences file
        SharedPreferences sh=context.getSharedPreferences("appDataFile", MODE_PRIVATE);

        // create editor for sharedPreferences
        SharedPreferences.Editor myEdit = sh.edit();

        //  write data on shared preferences
        myEdit.putString("name", userModel.getName());
        myEdit.putString("email", userModel.getEmail());
        myEdit.putString("imageURL", userModel.getImageURL());
        myEdit.putString("phoneNumber", userModel.getPhoneNumber());
        myEdit.putString("accountType", userModel.getAccountType());
        myEdit.putString("studentID", userModel.getStudentID());
        myEdit.apply();  // apply data
    }

    // getLogin function will return userModel stored in shared preferences
    public UserModel getLogin(){
        UserModel um=new UserModel();
        SharedPreferences sh=context.getSharedPreferences("appDataFile", MODE_PRIVATE);
          if(!sh.contains("name")){
              SharedPreferences.Editor myEdit = sh.edit();
              myEdit.putString("name", "");
              myEdit.putString("email", "");
              myEdit.putString("imageURL", "");
              myEdit.putString("phoneNumber", "");
              myEdit.putString("studentID", "");
              myEdit.putString("accountType", "");
              myEdit.apply();
          }
           um.setName(sh.getString("name",""));
            um.setEmail(sh.getString("email",""));
            um.setImageURL(sh.getString("imageURL",""));
            um.setPhoneNumber(sh.getString("phoneNumber",""));
            um.setStudentID(sh.getString("studentID",""));
            um.setAccountType(sh.getString("accountType",""));
            return um;

    }
}
