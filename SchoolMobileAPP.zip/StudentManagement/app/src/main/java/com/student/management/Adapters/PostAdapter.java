package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.student.management.Models.PostModel;
import com.student.management.R;
import java.util.List;


public class PostAdapter extends RecyclerView.Adapter<PostAdapter.CustomViewHolder> {
    List<PostModel> postModels;
    Context context;
    String operationType;
    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  contact(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          TextView textViewTitle
                  ,textViewDescription,textVIewDate,textViewPostedBy;

          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              textViewTitle=itemView.findViewById(R.id.textViewTitle);
              textViewDescription=itemView.findViewById(R.id.textViewDescription);
              textViewPostedBy=itemView.findViewById(R.id.textViewPostedBy);
              textVIewDate=itemView.findViewById(R.id.textVIewDate);

          }
    }
    public PostAdapter(List<PostModel> postModels, Context context, String type) {
        this.postModels =postModels;
        this.context = context;
        this.operationType=type;
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.post_item;
    }
    @Override
    public int getItemCount() {
        return  postModels.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
        holder.textViewTitle.setText(postModels.get(position).getPostTitle());
        holder.textViewDescription.setText(postModels.get(position).getPostDescription());
        holder.textViewPostedBy.setText("Posted By "+postModels.get(position).getName());
        holder.textVIewDate.setText(postModels.get(position).getDateAndTime());
      }
}
