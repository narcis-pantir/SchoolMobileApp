package com.student.management;

import android.app.Dialog;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.ChatAdapter;
import com.student.management.Models.Message;
import com.student.management.Models.UserModel;
import com.student.management.Utilities.MyHelper;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {
    String id = "";
    String name = "";
    String userNotificationID="";

    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference referenceSideOne,referenceSideTwo,reference;
    ImageView backArrow, imageViewSendBtn;
    RecyclerView recyclerView;
    EditText editTextUserInput;
    TextView txtName;
    UserModel userModel=null;
    MyHelper myHelper;
    List<Message> messages;
    List<Message> garMessages;
    ChatAdapter chatAdapter;
    private ToneGenerator toneGen1;
    UserModel targetUserModel=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        myHelper =new MyHelper(this);
        getIntentData();
        initBD();
        getUserData();
        initUI();
        initRecyclerView();
        getAllMessages();

    }

    private void initRecyclerView() {
        messages=new ArrayList<>();
        garMessages=new ArrayList<>();
        chatAdapter = new ChatAdapter(messages, this,"original");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(chatAdapter);
    }

    private void getAllMessages() {

        referenceSideOne.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull @NotNull DataSnapshot snapshot, @Nullable @org.jetbrains.annotations.Nullable String previousChildName) {
              Message message=snapshot.getValue(Message.class);
                messages.add(message);
                if(message.getMessageType().equals("other")){
                    toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP, 150);
                }

              chatAdapter.notifyDataSetChanged();
                if (!checkItemVisibility())
                    recyclerView.smoothScrollToPosition(chatAdapter.getItemCount() - 1);
            }

            @Override
            public void onChildChanged(@NonNull @NotNull DataSnapshot snapshot, @Nullable @org.jetbrains.annotations.Nullable String previousChildName) {
                Message message=snapshot.getValue(Message.class);
                messages.add(message);
                Toast.makeText(getApplicationContext(), "New Message recived", Toast.LENGTH_SHORT).show();
                if(message.getMessageType().equals("other")){
                    toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP, 150);
                }
                chatAdapter.notifyDataSetChanged();
                if (!checkItemVisibility())
                    recyclerView.smoothScrollToPosition(chatAdapter.getItemCount() - 1);
            }

            @Override
            public void onChildRemoved(@NonNull @NotNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull @NotNull DataSnapshot snapshot, @Nullable @org.jetbrains.annotations.Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


    }

    private void getUserData() {
        if(userModel==null){
            Dialog dialog= myHelper.openNetLoaderDialog();
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
              @Override
              public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                  dialog.dismiss();
                  if(snapshot.exists()){
                      userModel=snapshot.getValue(UserModel.class);
                  }else {
                      userModel=new UserModel();
                      userModel.setName(name);
                  }
              }

              @Override
              public void onCancelled(@NonNull @NotNull DatabaseError error) {
               dialog.dismiss();
              }
          });
        }
    }

    private void initUI() {
        toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);
        backArrow = findViewById(R.id.backArrow);
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        imageViewSendBtn = findViewById(R.id.imageViewSendBtn);
        recyclerView = findViewById(R.id.recyclerView);
        editTextUserInput = findViewById(R.id.editTextUserInput);
        txtName = findViewById(R.id.txtName);
        txtName.setText(name);
        imageViewSendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Message message=new Message();
                message.setMessage(editTextUserInput.getText().toString());
                message.setMessageType("my");
                message.setUserName(userModel.getName());
                message.setDate(myHelper.currentDate()+" "+ myHelper.currentTime());
                if(message.getMessage().equals("")){
                    Toast.makeText(ChatActivity.this, "Please enter message", Toast.LENGTH_SHORT).show();
                }else {
                    editTextUserInput.setText("");

                    referenceSideOne.push().setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            message.setMessageType("other");
                            referenceSideTwo.push().setValue(message).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void unused) {
                                    if(targetUserModel==null){
                                        DatabaseReference referenceNotification
                                                =FirebaseDatabase.getInstance()
                                                .getReference()
                                                .child("users")
                                                 .child(id)
                                                 .child("profileData");
                                        referenceNotification.addListenerForSingleValueEvent(new ValueEventListener() {
                                            @Override
                                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                                  if(snapshot.exists()){
                                                      targetUserModel=snapshot.getValue(UserModel.class);
                                                      userNotificationID=targetUserModel.getNotificationID();
                                                      getAppKey(message);
                                                  }else {
                                                      Toast.makeText(getApplicationContext(), "User Not using updated app, so we are unable to send notification", Toast.LENGTH_LONG).show();
                                                  }
                                            }

                                            @Override
                                            public void onCancelled(@NonNull DatabaseError error) {

                                            }
                                        });

                                    }else {
                                        getAppKey(message);
                                    }
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull @NotNull Exception e) {

                                }
                            });
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull @NotNull Exception e) {
                        }
                    });
                }
            }
        });
    }
    private void getAppKey(Message message) {
        sendNotification(message,getString(R.string.messagingServerKey));
    }

    private void sendNotification(Message message,String key) {
       // Toast.makeText(getApplicationContext(), userNotificationID, Toast.LENGTH_SHORT).show();

        RequestQueue requestQueue;
        String postUrl = "https://fcm.googleapis.com/fcm/send";
        requestQueue = Volley.newRequestQueue(this);
        JSONObject mainObj = new JSONObject();
        try {
            mainObj.put("to", userNotificationID);
            JSONObject notiObject = new JSONObject();
            notiObject.put("title", message.getUserName());
            notiObject.put("body", message.getMessage());
            notiObject.put("icon", "ic_app_logo"); // enter icon that exists in drawable only
            mainObj.put("notification", notiObject);
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, postUrl, mainObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                 //   Toast.makeText(getApplicationContext(), "Notification send ", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // code run is got error
                    Toast.makeText(getApplicationContext(), "Cant send notification"+error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> header = new HashMap<>();
                    header.put("content-type", "application/json");
                    header.put("authorization", "key=" + key);
                    return header;
                }
            };
            requestQueue.add(request);
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    private void initBD() {
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference()
                .child("users")
                .child(user.getUid())
                .child("profileData");
        referenceSideOne = FirebaseDatabase.getInstance().getReference()
                .child("chatBox")
                .child(user.getUid())
                .child(id);

        referenceSideTwo = FirebaseDatabase.getInstance().getReference()
                .child("chatBox")
                .child(id)
                .child(user.getUid());


    }

    private void getIntentData() {
        Intent intent = getIntent();
        id = intent.getStringExtra("chatID");
        name = intent.getStringExtra("name");
       // Toast.makeText(getApplicationContext(), id, Toast.LENGTH_LONG).show();



    }
    boolean checkItemVisibility() {
        LinearLayoutManager layoutManager = ((LinearLayoutManager) recyclerView.getLayoutManager());
        int pos = layoutManager.findLastCompletelyVisibleItemPosition();
        int numItems = recyclerView.getAdapter().getItemCount();
        return (pos >= numItems);
    }
}