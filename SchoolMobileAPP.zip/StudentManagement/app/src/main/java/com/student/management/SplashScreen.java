package com.student.management;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.student.management.Account.LoginActivity;
import com.student.management.Data.LocalData;
import com.student.management.Models.UserModel;

public class SplashScreen extends AppCompatActivity {


    FirebaseAuth auth;
    FirebaseUser user;
    LocalData localData;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        localData=new LocalData(this);  // initialize LocalData file
        intiFirebaseAuth();
        runThreadDelay();
    }
    private void intiFirebaseAuth() {
        // initialize auth and user object
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();
    }

    // this function will hold UI for 2 seconds
    private void runThreadDelay() {


        Thread myThread = new Thread() {
            @Override
            public void run() {
                try {

                    sleep(2000);  // thread sleep
                    if (isLogin()) {
                        UserModel us=localData.getLogin();
                        if(us.getAccountType().equals("teacher")){
                            startActivity(new Intent(SplashScreen.this, TeacherMain.class));
                        }else if(us.getAccountType().equals("student")){
                            startActivity(new Intent(SplashScreen.this, StudentMain.class));
                        }else if(us.getAccountType().equals("parents")){
                            startActivity(new Intent(SplashScreen.this, ParentsMain.class));
                        }
                    } else {
                        startActivity(new Intent(SplashScreen.this, LoginActivity.class));

                    }
                    finish();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        };
        myThread.start();
    }

    private boolean isLogin() {
        return user != null;
    }
}