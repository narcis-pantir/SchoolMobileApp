package com.student.management.Teachers;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.UserAdapter;
import com.student.management.ChatActivity;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;


// check AllTeacherActivity class working on the same way
// this class loading parents instead of teacher
public class AllParentsActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    LinearLayout layoutEmpty;
    List<UserModel> userModels;
    List<String> userIds;
    UserAdapter userAdapter;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    MyHelper myHelper;
    ImageView imageViewBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myHelper =new MyHelper(this);
        setContentView(R.layout.activity_all_parents);
        initDB();
        initViews();
        initRecyclerView();
        getAllUsers();
    }

    private void getAllUsers() {
        Dialog dialogLoading= myHelper.openNetLoaderDialog();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               userIds.clear();
               userModels.clear();
               dialogLoading.dismiss();
                for(DataSnapshot data:snapshot.getChildren()){
                    UserModel userModel=data.child("profileData").getValue(UserModel.class);
                   if(userModel.getAccountType().equals("parents") && !data.getKey().equals(user.getUid())){
                       userModels.add(userModel);
                       userIds.add(data.getKey());
                   }
               }
                if(userModels.size()>0){
                    recyclerView.setVisibility(View.VISIBLE);
                    layoutEmpty.setVisibility(View.GONE);
                }else {
                    recyclerView.setVisibility(View.GONE);
                    layoutEmpty.setVisibility(View.VISIBLE);
                }
               userAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
              dialogLoading.dismiss();
                Toast.makeText(AllParentsActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initRecyclerView() {
        userModels=new ArrayList<>();
        userIds=new ArrayList<>();
        userAdapter=new UserAdapter(userModels,this,"parents");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(userAdapter);
        userAdapter.setOnItemClickListener(new UserAdapter.onItemClickListener() {
            @Override
            public void contact(int position) {
                Intent intent=new Intent(AllParentsActivity.this, ChatActivity.class);
                intent.putExtra("chatID",userIds.get(position));
                intent.putExtra("name",userModels.get(position).getName());
                startActivity(intent);


            }
        });



    }

    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
    }

    private void initViews() {
        recyclerView=findViewById(R.id.recyclerView);
        layoutEmpty=findViewById(R.id.layoutEmpty);
        imageViewBack=findViewById(R.id.imageViewBack);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             finish();
            }
        });
    }
}