package com.student.management;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.messaging.FirebaseMessaging;
import com.squareup.picasso.Picasso;
import com.student.management.Account.LoginActivity;
import com.student.management.Data.LocalData;
import com.student.management.Models.UserModel;
import com.student.management.Teachers.AllParentsActivity;
import com.student.management.Teachers.AllStudentActivity;
import com.student.management.Teachers.AttendanceActivity;
import com.student.management.Teachers.AssignmentsActivity;
import com.student.management.Teachers.InboxActivity;
import com.student.management.Teachers.NotifyParentsActivity;
import com.student.management.Utilities.MyHelper;

public class TeacherMain extends AppCompatActivity {
    ImageView imageVIewLogout,imageViewTeacherProfile;
    TextView textViewName,textViewEmail
            ,textViewPhone;
    Button buttonInbox,buttonStudent,buttonParents
            ,buttonPosts,buttonAttendance,buttonGrades
            ,buttonClass;
    LocalData localData;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    MyHelper myHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_main);
        localData=new LocalData(this);
        myHelper =new MyHelper(this);
        initDB();
        initViews();
        getUserData();
        updateNotificationID();
    }
    private void getUserData() {
        Dialog dialogLoading= myHelper.openNetLoaderDialog();
        reference.child("profileData").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialogLoading.dismiss();
                if(snapshot.exists()){
                    UserModel userModel=snapshot.getValue(UserModel.class);
                    writeDataOnUI(userModel);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });
    }
    @SuppressLint("SuspiciousIndentation")
    private void writeDataOnUI(UserModel userModel) {
        textViewName.setText(userModel.getName());
        textViewEmail.setText(userModel.getEmail());
        textViewPhone.setText(userModel.getPhoneNumber());
        if(!userModel.getImageURL().equals(""))
        Picasso.get().load(userModel.getImageURL())
                .placeholder(getDrawable(R.drawable.person_place_holder))
                .into(imageViewTeacherProfile);
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users")
                .child(user.getUid());
    }
    private void initViews() {
        imageVIewLogout=findViewById(R.id.imageVIewLogout);
        imageViewTeacherProfile=findViewById(R.id.imageViewTeacherProfile);
        buttonClass=findViewById(R.id.buttonClass);
        imageVIewLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserModel us=new UserModel();
                us.setName("");
                us.setAccountType("");
                us.setImageURL("");
                us.setPhoneNumber("");
                us.setEmail("");
                us.setStudentID("");
                localData.setLogin(us);
                if(user!=null){
                    auth.signOut();
                    startActivity(new Intent(TeacherMain.this, LoginActivity.class));
                    finish();
                }
            }
        });
        buttonInbox=findViewById(R.id.buttonInbox);
        textViewName=findViewById(R.id.textViewName);
        textViewEmail=findViewById(R.id.textViewEmail);
        textViewPhone=findViewById(R.id.textViewPhone);
        buttonStudent=findViewById(R.id.buttonStudent);
        buttonParents=findViewById(R.id.buttonParents);
        buttonPosts=findViewById(R.id.buttonPosts);
        buttonAttendance=findViewById(R.id.buttonAttendance);
        buttonGrades=findViewById(R.id.buttonGrades);
        buttonPosts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this,PostsActivity.class));
            }
        });
        buttonInbox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this, InboxActivity.class));
            }
        });
        buttonStudent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this, AllStudentActivity.class));
            }
        });
        buttonParents.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this, AllParentsActivity.class));
            }
        });
        buttonAttendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this, AttendanceActivity.class));
            }
        });
        buttonGrades.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TeacherMain.this, AssignmentsActivity.class));
            }
        });
        buttonClass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
            startActivity(new Intent(TeacherMain.this, NotifyParentsActivity.class));
            }
        });


    }
    private void updateNotificationID() {
        // do is a background
        FirebaseMessaging.getInstance().getToken().addOnSuccessListener(new OnSuccessListener<String>() {
            @Override
            public void onSuccess(String s) {
                reference.child("profileData").child("notificationID")
                        .setValue(s);
            }
        });
    }
}