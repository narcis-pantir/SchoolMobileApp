package com.student.management.Utilities;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.widget.Toast;
import com.student.management.R;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;

public class MyHelper {
    Context context;
    public MyHelper(Context context) {
        this.context = context;
    }

    // this method validate email
    public boolean isEmailValid(String email_string) {

        // check all not supported character in the email
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\."+
                "[a-zA-Z0-9_+&*-]+)*@" +
                "(?:[a-zA-Z0-9-]+\\.)+[a-z" +
                "A-Z]{2,7}$";
        Pattern pat = Pattern.compile(emailRegex);
        if (email_string == null)
            return false;
        return pat.matcher(email_string).matches();
    }
    public String currentDate(){
          return  new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
       }
    public String currentTime(){
        return  new SimpleDateFormat("h:mm a", Locale.getDefault()).format(new Date());
    }
    public Dialog openNetLoaderDialog() {
        Dialog dialogP=new Dialog(context);// create dialog

        // set layout on DIalog
        dialogP.setContentView(R.layout.dialog_loading);

        // remove layout from dialog
        dialogP.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialogP.setCancelable(false);
        dialogP.show();  // show dialog
        return dialogP;  // return dialog
    }
    public void messageDialog(String title,String message) {
        Toast.makeText(context, title+" :"+message, Toast.LENGTH_SHORT).show();
    }
}
