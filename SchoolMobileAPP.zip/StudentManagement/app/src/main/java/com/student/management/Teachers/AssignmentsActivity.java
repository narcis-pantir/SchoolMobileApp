package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.AssignmentAdapter;
import com.student.management.Models.Assignment;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class AssignmentsActivity extends AppCompatActivity {
    ImageView imageViewBack;
    LinearLayout layoutEmpty;
    RecyclerView recyclerView;
    MyHelper myHelper;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    List<Assignment> assignments;
    List<String> ids;
    AssignmentAdapter assignmentAdapter;
    FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assignments);
        initDB();
        initViews();
        initRecyclerView();
        getAllAssignments();
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("assignments");
    }
    private void getAllAssignments() {
        Dialog dialog= myHelper.openNetLoaderDialog();
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                ids.clear();
                assignments.clear();
                for(DataSnapshot data:snapshot.getChildren()){
                    assignments.add(data.getValue(Assignment.class));
                    ids.add(data.getKey());
                }
                if(assignments.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                assignmentAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialog.dismiss();
                Toast.makeText(AssignmentsActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initRecyclerView() {
        assignments=new ArrayList<>();
        ids=new ArrayList<>();
        assignmentAdapter=new AssignmentAdapter(assignments,this,"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(assignmentAdapter);
        assignmentAdapter.setOnItemClickListener(new AssignmentAdapter.onItemClickListener() {
            @Override
            public void grades(int position) {
                Intent intent=new Intent(AssignmentsActivity.this,GradeActivity.class);
                intent.putExtra("assignmentName",assignments.get(position).getAssignmentName());
                intent.putExtra("assignmentID",ids.get(position));
                intent.putExtra("operationType","teacher");
                startActivity(intent);
            }
        });

    }
    private void initViews() {
        imageViewBack=findViewById(R.id.imageViewBack);
        floatingActionButton=findViewById(R.id.floatingActionButton);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        layoutEmpty=findViewById(R.id.layoutEmpty);
        recyclerView=findViewById(R.id.recyclerView);
        myHelper =new MyHelper(this);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialogPost();
            }
        });
    }
    private void openDialogPost() {
        Dialog dialog=new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_add_assignment);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        EditText editTextTitle;
        TextView textViewCancel,textViewSubmit;
        editTextTitle=dialog.findViewById(R.id.editTextTitle);
        textViewCancel=dialog.findViewById(R.id.textViewCancel);
        textViewSubmit=dialog.findViewById(R.id.textViewSubmit);
        textViewCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        textViewSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String assignmentTitle=editTextTitle.getText().toString();
                if(assignmentTitle.equals("")){
                    editTextTitle.setError("Assignment title required ");
                }else {
                    Assignment assignment=new Assignment();
                    assignment.setAssignmentName(assignmentTitle);
                    uploadPost(assignment);
                    dialog.dismiss();
                }



            }
        });
    }
    private void uploadPost(Assignment assignment) {
        Dialog dialog= myHelper.openNetLoaderDialog();
        reference.push().setValue(assignment).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                dialog.dismiss();
                Toast.makeText(AssignmentsActivity.this, "Posted successfully ", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Toast.makeText(AssignmentsActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}