package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;
import com.student.management.Models.Message;
import com.student.management.Models.UserModel;
import com.student.management.R;

import java.util.List;


public class UserAdapter extends RecyclerView.Adapter<UserAdapter.CustomViewHolder> {
    List<UserModel> userModels;
    Context context;
    String operationType;
    DatabaseReference reference;

    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  contact(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          ImageView imageViewProfileImage;
          TextView textViewName,textViewEmail
                  ,textViewPhone,textViewStudentName;
          Button buttonContact;


          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              imageViewProfileImage=itemView.findViewById(R.id.imageViewProfileImage);
              textViewName=itemView.findViewById(R.id.textViewName);
              textViewEmail=itemView.findViewById(R.id.textViewEmail);
              textViewPhone=itemView.findViewById(R.id.textViewPhone);
              textViewStudentName=itemView.findViewById(R.id.textViewStudentName);
              buttonContact=itemView.findViewById(R.id.buttonContact);
        buttonContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos=getAdapterPosition();
                if(listener!=null){
                    listener.contact(pos);
                }
            }
        });


          }
    }
    public UserAdapter(List<UserModel> userModels, Context context, String type) {
        this.userModels =userModels;
        this.context = context;
        this.operationType=type;
        reference= FirebaseDatabase.getInstance().getReference()
                .child("users");
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.user_item;
    }
    @Override
    public int getItemCount() {
        return  userModels.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
     holder.textViewEmail.setText(userModels.get(position).getEmail());
     holder.textViewName.setText(userModels.get(position).getName());
     holder.textViewPhone.setText(userModels.get(position).getPhoneNumber());
     if(operationType.equals("student")){
         holder.textViewStudentName.setVisibility(View.GONE);
     }else {
         holder.textViewStudentName.setVisibility(View.VISIBLE);
         reference.child(userModels.get(position).getStudentID()).child("profileData").addListenerForSingleValueEvent(new ValueEventListener() {
             @Override
             public void onDataChange(@NonNull DataSnapshot snapshot) {
                 if(snapshot.exists()){
                     UserModel userModel=snapshot.getValue(UserModel.class);
                     holder.textViewStudentName.setText("Parents of : "+userModel.getName());
                 }
             }

             @Override
             public void onCancelled(@NonNull DatabaseError error) {

             }
         });


     }
     if(!userModels.get(position).getImageURL().equals("")) {
         Picasso.get().load(userModels.get(position).getImageURL())
                 .placeholder(context.getDrawable(R.drawable.person_place_holder))
                 .into(holder.imageViewProfileImage);
     }
      }
}
