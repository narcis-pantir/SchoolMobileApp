package com.student.management.Models;

public class Inbox {
    String id;

    public Inbox() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
