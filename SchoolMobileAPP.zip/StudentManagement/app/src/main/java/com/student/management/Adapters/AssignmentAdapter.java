package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;
import com.student.management.Models.Assignment;
import com.student.management.Models.UserModel;
import com.student.management.R;

import java.util.List;


public class AssignmentAdapter extends RecyclerView.Adapter<AssignmentAdapter.CustomViewHolder> {
    List<Assignment> assignments;  // list will hold all assignments Models
    Context context;  // activity context
    String operationType;

    private  onItemClickListener mListener;  // Listener for item click

    // Interface for click Listener
      public  interface onItemClickListener{
          void  grades(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }

    // Adapter CustomViewHolder
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          TextView textViewAssignmentName;  // widget on UI
          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
             //  connect UI widget
             textViewAssignmentName=itemView.findViewById(R.id.textViewAssignmentName);

             // click listener for Item
             itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos=getAdapterPosition();  // get adapter position
                if(listener!=null){  // if listener not null
                    listener.grades(pos);  // call interface with position
                }
            }
        });

          }
    }

    // adapter constructor which use to initialize list and context
    public AssignmentAdapter(List<Assignment> assignments, Context context, String type) {
        this.assignments =assignments;
        this.context = context;
        this.operationType=type;
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.assignment_item;  //  set layout on Adapter
    }
    @Override
    public int getItemCount() {  // get size of list
        return  assignments.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
          // onBindViewHolder Used to write data on UI


        // write assignment name on textView
          holder.textViewAssignmentName.setText(assignments.get(position).getAssignmentName());
      }
}
