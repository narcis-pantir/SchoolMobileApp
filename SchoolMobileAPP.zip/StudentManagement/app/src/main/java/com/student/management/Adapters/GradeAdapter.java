package com.student.management.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.student.management.Models.Assignment;
import com.student.management.Models.GradeModel;
import com.student.management.R;

import java.util.List;


public class GradeAdapter extends RecyclerView.Adapter<GradeAdapter.CustomViewHolder> {
    List<GradeModel> gradeModels;
    Context context;
    String operationType;

    private  onItemClickListener mListener;
      public  interface onItemClickListener{
          void  grades(int position);
        }
     public  void setOnItemClickListener(onItemClickListener listener){//item click listener initialization
          mListener=listener;
     }
     public static class  CustomViewHolder extends RecyclerView.ViewHolder{
          TextView textViewName,textViewGrade;
          Button buttonAssignGrade;
          public CustomViewHolder(View itemView, final onItemClickListener listener) {
             super(itemView);
              textViewName=itemView.findViewById(R.id.textViewName);
              textViewGrade=itemView.findViewById(R.id.textViewGrade);
              buttonAssignGrade=itemView.findViewById(R.id.buttonAssignGrade);
       buttonAssignGrade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int pos=getAdapterPosition();
                if(listener!=null){
                    listener.grades(pos);
                }
            }
        });

          }
    }
    public GradeAdapter(List<GradeModel> gradeModels, Context context, String type) {
        this.gradeModels =gradeModels;
        this.context = context;
        this.operationType=type;
    }
    @Override
    public int getItemViewType(int position) {
          return R.layout.grade_item;
    }
    @Override
    public int getItemCount() {
        return  gradeModels.size();
    }
    @Override
    public CustomViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(viewType, parent, false),mListener);
    }
    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(CustomViewHolder holder, int position) {
         holder.textViewName.setText(gradeModels.get(position).getStudentName());
         holder.textViewGrade.setText(gradeModels.get(position).getStudentGrade());
         if(!operationType.equals("teacher")){
             holder.buttonAssignGrade.setVisibility(View.GONE);
         }
      }
}
