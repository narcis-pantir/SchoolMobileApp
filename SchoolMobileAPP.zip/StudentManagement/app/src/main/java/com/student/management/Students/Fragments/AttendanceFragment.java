package com.student.management.Students.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.AttendanceAdapter;
import com.student.management.Data.LocalData;
import com.student.management.Models.Attendance;
import com.student.management.R;

import java.util.ArrayList;
import java.util.List;

public class AttendanceFragment extends Fragment {
    View view;   // view that contain fragment view
    RecyclerView recyclerView;
    LinearLayout layoutEmpty,layoutLoading;
    List<Attendance> attendances; // attendance list
    AttendanceAdapter attendanceAdapter;  // attendance adapter
    DatabaseReference reference;
    FirebaseAuth auth;
    FirebaseUser user;
    String id="";
    LocalData localData;
    TextView textViewTop;

      //fragment empty constructor
    public AttendanceFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // set view on fragment
        view= inflater.inflate(R.layout.fragment_attendance, container, false);
        localData=new LocalData(getContext());
        initDB();
        initViews();
        initRecyclerView();
        getAllAttendance();
        return view;
    }

    /***Initialize recycler view check AllTeacherActivity class
     * working on the same way
     * ****/
    private void initRecyclerView() {
        attendances=new ArrayList<>();
        attendanceAdapter=new AttendanceAdapter(attendances,getContext(),"student");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(attendanceAdapter);
    }
    private void getAllAttendance() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
              layoutLoading.setVisibility(View.GONE);
                for(DataSnapshot data:snapshot.getChildren()){
                    attendances.add(data.getValue(Attendance.class));
                }
                if(attendances.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                attendanceAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        if(localData.getLogin().getAccountType().equals("student")){
            id=user.getUid();
        }else {
            id=localData.getLogin().getStudentID();
        }

        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users")
                .child(id)
                .child("attendance");
    }

    private void initViews() {
        layoutLoading=view.findViewById(R.id.layoutLoading);
        layoutEmpty=view.findViewById(R.id.layoutEmpty);
        recyclerView=view.findViewById(R.id.recyclerView);
        textViewTop=view.findViewById(R.id.textViewTop);
        if(localData.getLogin().getAccountType().equals("parents")){
            textViewTop.setText("Attendance record of your son/daughter");
        }

    }
}