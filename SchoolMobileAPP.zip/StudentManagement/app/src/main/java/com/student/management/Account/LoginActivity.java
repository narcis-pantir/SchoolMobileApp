package com.student.management.Account;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Data.LocalData;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.SplashScreen;
import com.student.management.Utilities.MyHelper;

public class LoginActivity extends AppCompatActivity {

    // variables for UI widgets
    EditText editTextEmail,editTextPassword;
    Button buttonLogin;
    TextView textViewRegistration,textViewForgetPassword;

    // Firebase objects
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;


    MyHelper myHelper;  // helper class object
    LocalData localData;  // local data object
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        localData=new LocalData(this);  // initialize localData object
        myHelper =new MyHelper(this);  //initialize helper object
        initDB();  // call init DB function
        initViews();  // call initViews function
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();  // get Auth instance
        user=auth.getCurrentUser();  // get current user from auth object

       // reference to firebase realtime database "users" child
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");  // "users" child
    }
    private void initViews() {

         // connect all UI widgets
        editTextEmail=findViewById(R.id.editTextEmail);
        editTextPassword=findViewById(R.id.editTextPassword);
        buttonLogin=findViewById(R.id.buttonLogin);
        textViewForgetPassword=findViewById(R.id.textViewForgetPassword);
        textViewRegistration=findViewById(R.id.textViewRegistration);


        // click listener for textViewRegistration
        textViewRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {  // click listener

                // open Registration Activity
                startActivity(new Intent(LoginActivity.this,RegistrationActivity.class));
            }
        });

        // click listener for forgetPassword
        textViewForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {  // Listener

                // open forget password activity
             startActivity(new Intent(LoginActivity.this,ResetPasswordActivity.class));
            }
        });


        // button login click Listener
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // get email and password from user
                String email=editTextEmail.getText().toString();
                String password=editTextPassword.getText().toString();

               // validate all the data
                if(email.equals("")){
                    editTextEmail.setError("Email Required");
                }else if(!myHelper.isEmailValid(email)){
                    editTextEmail.setError("Invalid Email");
                }else if(password.equals("")){
                    editTextPassword.setError("Password required");
                }else{

                    // call do login function passing email and password
                    doLogin(email,password);
                }
            }
        });
    }
    private void doLogin(String email,String password) {

        // open progress dialog using myHelper
        Dialog dialog= myHelper.openNetLoaderDialog();

        // sign In user with email and password
        auth.signInWithEmailAndPassword(email,password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {  // if login successfull
                dialog.dismiss();  //close dialog

                // display Toast
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                user=auth.getCurrentUser();  // get login user

                // get data of current user from firebase database
                reference.child(user.getUid()).child("profileData")
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        // get user data in userModel
                                        UserModel userModel=snapshot.getValue(UserModel.class);
                                        localData.setLogin(userModel);  // store login data

                                        // now open splash screen so the app will decide to which activity the app will open
                                        // according to user type
                                        startActivity(new Intent(LoginActivity.this, SplashScreen.class));
                                        finish();
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {

                                    }
                                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                /***This method will trigger if login filed
                 * like password or email not exist in firebase auth  **/

              dialog.dismiss();  // close dialog

              // display message
              myHelper.messageDialog("Error",e.getMessage());
            }
        });
    }
}