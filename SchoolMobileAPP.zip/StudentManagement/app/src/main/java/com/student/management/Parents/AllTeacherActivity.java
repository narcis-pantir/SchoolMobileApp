package com.student.management.Parents;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.UserAdapter;
import com.student.management.ChatActivity;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class AllTeacherActivity extends AppCompatActivity {

    RecyclerView recyclerView;//recycler view widget
    LinearLayout layoutEmpty;

    // list of users model list
    List<UserModel> userModels;
    List<String> userIds;
    UserAdapter userAdapter;  // user adapter
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    MyHelper myHelper;
    ImageView imageViewBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        myHelper =new MyHelper(this);
        setContentView(R.layout.activity_all_teacher);

        // functions
        initDB();
        initViews();
        initRecyclerView();
        getAllUsers();
    }

    private void getAllUsers() {
        Dialog dialogLoading= myHelper.openNetLoaderDialog();

      /****    reference belong to "users" child
       * reference.addValueEventListener(Listener) will load all
       * users from "users" child
       *This function will also call automatically if any user added or change
       * **/
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                userIds.clear();  // clear all IDS
                userModels.clear();  // clear all IDS
                dialogLoading.dismiss();  // close loading dialog

                // travers all users
                for(DataSnapshot data:snapshot.getChildren()){

                    // get user data in user model
                    UserModel userModel=data.child("profileData").getValue(UserModel.class);

                    //Only add those users who are teacher
                    if(userModel.getAccountType().equals("teacher")){
                        userModels.add(userModel);
                        userIds.add(data.getKey());
                    }
                }

                // check if teacher exist or not
                if(userModels.size()>0){// if teacher exist

                    // visible recycler view
                    recyclerView.setVisibility(View.VISIBLE);

                    // hide empty layout
                    layoutEmpty.setVisibility(View.GONE);
                }else {  // if teacher not exist

                    // hide recycler view
                    recyclerView.setVisibility(View.GONE);

                    //visible layout empty
                    layoutEmpty.setVisibility(View.VISIBLE);
                }

                // notify adapter about changes
                userAdapter.notifyDataSetChanged();

            }

            @Override   // on data Load Filed
            public void onCancelled(@NonNull DatabaseError error) {
                dialogLoading.dismiss();
                Toast.makeText(AllTeacherActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }



    private void initRecyclerView() {
        userModels=new ArrayList<>();  // initialize users data list
        userIds=new ArrayList<>();  // initialize users id list



        // initialize user adapter
        userAdapter=new UserAdapter(userModels,this,"student");

       // set recycler view layout to vertical
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));

        // set adapter on recycler view
        recyclerView.setAdapter(userAdapter);


        // adapter on click Listener
        userAdapter.setOnItemClickListener(new UserAdapter.onItemClickListener() {
            @Override
            public void contact(int position) {

                // create intent to chat
                Intent intent=new Intent(AllTeacherActivity.this, ChatActivity.class);

                // pass target user ID
                intent.putExtra("chatID",userIds.get(position));

                // pass target user name
                intent.putExtra("name",userModels.get(position).getName());
                startActivity(intent);  // start chat Activity
            }
        });



    }

    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
    }

    private void initViews() {
        recyclerView=findViewById(R.id.recyclerView);
        layoutEmpty=findViewById(R.id.layoutEmpty);
        imageViewBack=findViewById(R.id.imageViewBack);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}