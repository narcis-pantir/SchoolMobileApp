package com.student.management.Teachers;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Models.UserModel;
import com.student.management.R;
import com.student.management.Utilities.MyHelper;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NotifyParentsActivity extends AppCompatActivity {
      ImageView imageViewBack;
      EditText editTextTitle,editTextMessage;
      Button buttonSubmit;
      List<UserModel> parentsList;
      MyHelper myHelper;
      DatabaseReference reference;
    RequestQueue requestQueue;  // vollay library request queue
    int index=0;
    Dialog dialogLoading;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notify_parents);
        myHelper =new MyHelper(this);

        // initialize request queue
        requestQueue = Volley.newRequestQueue(this);
        initDB();
        initView();
        getAllParents();
    }

    //  get all parents data check AllTeacherActivity class
    // working on the same way
    private void getAllParents() {
        parentsList=new ArrayList<>();
        Dialog dialogLoading= myHelper.openNetLoaderDialog();
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                parentsList.clear();
                dialogLoading.dismiss();
                for(DataSnapshot data:snapshot.getChildren()){
                    UserModel userModel=data.child("profileData").getValue(UserModel.class);
                    if(userModel.getAccountType().equals("parents")){
                        parentsList.add(userModel);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                dialogLoading.dismiss();
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initDB() {
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users");
    }
    private void initView() {
        imageViewBack=findViewById(R.id.imageViewBack);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        editTextTitle=findViewById(R.id.editTextTitle);
        editTextMessage=findViewById(R.id.editTextMessage);
        buttonSubmit=findViewById(R.id.buttonSubmit);

        // button submit click Listener
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //  get title and message from UI
                String title=editTextTitle.getText().toString();
                String message=editTextMessage.getText().toString();

                //validate data
                if(title.equals("")){
                    editTextTitle.setError("Title Required");
                }else if(message.equals("")){
                    editTextMessage.setError("Message Required");
                }else {
                    if(parentsList.size()>0){
                        dialogLoading= myHelper.openNetLoaderDialog();
                    }else {
                        Toast.makeText(NotifyParentsActivity.this, "No parents found to send notification ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                     index=0;

                    for(int i=0;i<parentsList.size();i++){
                        if(!parentsList.get(i).getNotificationID().equals("")){
                            index=index+1;
                            // call send notification function
                            sendNotification(title,message,parentsList.get(i).getNotificationID());
                        }

                    }
                    if(index==0){
                        dialogLoading.dismiss();
                    }

                }
            }
        });
    }
    private void sendNotification(String title,String message,String notificationID) {
        // Toast.makeText(getApplicationContext(), userNotificationID, Toast.LENGTH_SHORT).show();

            // FCM server URL
        String postUrl = "https://fcm.googleapis.com/fcm/send";


        // create json object for message
        JSONObject mainObj = new JSONObject();

        // set data on objet
        try {
            mainObj.put("to", notificationID);
            JSONObject notiObject = new JSONObject();
            notiObject.put("title", title);
            notiObject.put("body", message);
            notiObject.put("icon", "ic_app_logo"); // enter icon that exists in drawable only
            mainObj.put("notification", notiObject);

            // create JsonObjectRequest
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, postUrl, mainObj, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Toast.makeText(NotifyParentsActivity.this, "Parents notified", Toast.LENGTH_SHORT).show();
                        dialogLoading.dismiss();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // code run is got error
                    dialogLoading.dismiss();
                    Toast.makeText(getApplicationContext(), "Cant send notification"+error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override  // provide app key in header
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> header = new HashMap<>();
                    header.put("content-type", "application/json");
                    header.put("authorization", "key=" + getString(R.string.messagingServerKey));
                    return header;
                }
            };
            requestQueue.add(request);  // add request to request queue
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }



}