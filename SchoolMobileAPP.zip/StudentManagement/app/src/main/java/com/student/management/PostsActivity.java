package com.student.management;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.PostAdapter;
import com.student.management.Models.PostModel;
import com.student.management.Models.UserModel;
import com.student.management.Utilities.MyHelper;

import java.util.ArrayList;
import java.util.List;

public class PostsActivity extends AppCompatActivity {
     ImageView imageViewBack;
     LinearLayout layoutEmpty;
     RecyclerView recyclerView;
     MyHelper myHelper;
     FirebaseAuth auth;
     FirebaseUser user;
     DatabaseReference reference,referencePost;
     List<PostModel> postModels;
     List<String> ids;
     PostAdapter postAdapter;
     UserModel userModel=null;
     FloatingActionButton floatingActionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_posts);
        initDB();
        initViews();
        initRecyclerView();
        getUserData();
        getAllPosts();
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("users")
                .child(user.getUid())
                .child("profileData");
        referencePost= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("posts");
    }
    private void getAllPosts() {
        Dialog dialog= myHelper.openNetLoaderDialog();
        referencePost.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                dialog.dismiss();
                ids.clear();
                postModels.clear();
                for(DataSnapshot data:snapshot.getChildren()){
                    postModels.add(data.getValue(PostModel.class));
                    ids.add(data.getKey());
                }
                if(postModels.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                postAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
               dialog.dismiss();
                Toast.makeText(PostsActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void getUserData() {
        reference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    userModel=snapshot.getValue(UserModel.class);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(PostsActivity.this, error.getCode(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initRecyclerView() {
        postModels=new ArrayList<>();
        ids=new ArrayList<>();
        postAdapter=new PostAdapter(postModels,this,"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(postAdapter);
    }
    private void initViews() {
        imageViewBack=findViewById(R.id.imageViewBack);
        floatingActionButton=findViewById(R.id.floatingActionButton);
        imageViewBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        layoutEmpty=findViewById(R.id.layoutEmpty);
        recyclerView=findViewById(R.id.recyclerView);
        myHelper =new MyHelper(this);
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              openDialogPost();
            }
        });
    }
    private void openDialogPost() {
        if(userModel==null){
            Toast.makeText(this, "Please wait for while application downloading data...", Toast.LENGTH_SHORT).show();
            return;
        }
        Dialog dialog=new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_add_post);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.show();
        EditText editTextTitle,editTextDescriptions;
        TextView textViewCancel,textViewSubmit;
        editTextTitle=dialog.findViewById(R.id.editTextTitle);
        editTextDescriptions=dialog.findViewById(R.id.editTextDescriptions);
        textViewCancel=dialog.findViewById(R.id.textViewCancel);
        textViewSubmit=dialog.findViewById(R.id.textViewSubmit);
        textViewCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
     textViewSubmit.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View view) {
             PostModel postModel=new PostModel();
             postModel.setName(userModel.getName());
             postModel.setHostID(user.getUid());
             postModel.setDateAndTime(myHelper.currentDate()+" "+ myHelper.currentTime());
             postModel.setPostDescription(editTextDescriptions.getText().toString());
             postModel.setPostTitle(editTextTitle.getText().toString());
             if(postModel.getPostTitle().equals("")){
                 editTextTitle.setError("Title required");
             }else if(postModel.getPostDescription().equals("")){
                  editTextDescriptions.setError("Post description required ");
             }else {
                  uploadPost(postModel);
                  dialog.dismiss();
             }
         }
     });
    }
    private void uploadPost(PostModel postModel) {
        Dialog dialog= myHelper.openNetLoaderDialog();
        referencePost.push().setValue(postModel).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                dialog.dismiss();
                Toast.makeText(PostsActivity.this, "Posted successfully ", Toast.LENGTH_SHORT).show();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
              dialog.dismiss();
                Toast.makeText(PostsActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}