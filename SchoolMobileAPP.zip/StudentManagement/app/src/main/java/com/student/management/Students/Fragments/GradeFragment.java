package com.student.management.Students.Fragments;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.student.management.Adapters.AssignmentAdapter;
import com.student.management.Models.Assignment;
import com.student.management.R;
import com.student.management.Teachers.AssignmentsActivity;
import com.student.management.Teachers.GradeActivity;

import java.util.ArrayList;
import java.util.List;

public class GradeFragment extends Fragment {
    View view;
    RecyclerView recyclerView;
    LinearLayout layoutEmpty,layoutLoading;
    FirebaseAuth auth;
    FirebaseUser user;
    DatabaseReference reference;
    List<Assignment> assignments;
    List<String> ids;
    AssignmentAdapter assignmentAdapter;
    public GradeFragment() {
    }
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view= inflater.inflate(R.layout.fragment_grades, container, false);
        initDB();
        initViews();
        initRecyclerView();
        getAllAssignments();
        return view;
    }

    private void initViews() {
        layoutLoading=view.findViewById(R.id.layoutLoading);
        layoutEmpty=view.findViewById(R.id.layoutEmpty);
        recyclerView=view.findViewById(R.id.recyclerView);
    }
    private void initDB() {
        auth=FirebaseAuth.getInstance();
        user=auth.getCurrentUser();
        reference= FirebaseDatabase
                .getInstance()
                .getReference()
                .child("assignments");
    }
    private void getAllAssignments() {
        layoutLoading.setVisibility(View.VISIBLE);
        layoutEmpty.setVisibility(View.GONE);
        recyclerView.setVisibility(View.GONE);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                layoutLoading.setVisibility(View.GONE);
                ids.clear();
                assignments.clear();
                for(DataSnapshot data:snapshot.getChildren()){
                    assignments.add(data.getValue(Assignment.class));
                    ids.add(data.getKey());
                }
                if(assignments.size()>0){
                    layoutEmpty.setVisibility(View.GONE);
                    recyclerView.setVisibility(View.VISIBLE);
                }else {
                    layoutEmpty.setVisibility(View.VISIBLE);
                    recyclerView.setVisibility(View.GONE);
                }
                assignmentAdapter.notifyDataSetChanged();
            }
            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                layoutLoading.setVisibility(View.GONE);
                Toast.makeText(getContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void initRecyclerView() {
        assignments=new ArrayList<>();
        ids=new ArrayList<>();
        assignmentAdapter=new AssignmentAdapter(assignments,getContext(),"teacher");
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext(),LinearLayoutManager.VERTICAL, false));
        recyclerView.setAdapter(assignmentAdapter);
        assignmentAdapter.setOnItemClickListener(new AssignmentAdapter.onItemClickListener() {
            @Override
            public void grades(int position) {
                Intent intent=new Intent(getActivity(), GradeActivity.class);

                intent.putExtra("assignmentName",assignments.get(position).getAssignmentName());
                intent.putExtra("assignmentID",ids.get(position));
                intent.putExtra("operationType","student");
                startActivity(intent);
            }
        });

    }
}